package com.abc.test;

import com.abc.bean.Student;
import com.abc.dao.IStudentDao;
import com.abc.utils.MyBatisUtil;
import org.apache.ibatis.session.SqlSession;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MyTest {
   private IStudentDao dao;
   private SqlSession sqlSession;
    @Before
    public void before() throws IOException {
        // dao=new StudentDaoImpl();
        sqlSession = MyBatisUtil.getSqlSession();
        //生成dao接口的实现类对象
        dao = sqlSession.getMapper(IStudentDao.class);
    }
    @After
    public void after(){
        if (sqlSession!=null){
            sqlSession.close();
        }
    }
    @Test
    public  void test01() {
        Student student=new Student("张一一",20,99);
        //IStudentDao dao=new StudentDaoImpl();
        dao.insertStudent(student);
        sqlSession.commit();
    }
    @Test
    public void test02(){
        Student student=new Student("张恒",25,100);
        //IStudentDao dao=new StudentDaoImpl();
        System.out.println("插入前："+student);
        dao.insertStudent(student);
        sqlSession.commit();
        System.out.println("插入后："+student);
    }
    @Test
    public void test03(){
        Student student=new Student("李四",19,70);
        student.setId(3);
        //IStudentDao dao=new StudentDaoImpl();
        dao.updateStudent(student);
        sqlSession.commit();
    }
    @Test
    public void test04(){
        //IStudentDao dao=new StudentDaoImpl();
        dao.deleteById(4);
        sqlSession.commit();
    }
    @Test
    public void test05(){
       //IStudentDao dao=new StudentDaoImpl();
        List<Student> list =dao.selectAllStudent();
        for(Student stu:list){
            System.out.println(stu);
        }
    }
    @Test
    public void test06(){
       // IStudentDao dao=new StudentDaoImpl();
        Student student=dao.selectStudentById(3);
           System.out.println(student);

    }
    @Test
    public void test07(){
        //自动生成变量名的 快捷键ctrl+alt+v
        //IStudentDao dao=new StudentDaoImpl();
        Map<Object, Student> map = dao.selectAllStudentMap();
        System.out.println(map.size());
        Student student = map.get("张飞");
        System.out.println(student);
    }
    @Test
    public void test08(){
        List<Student> list = dao.selectStudentByName("张");
        //        效率低，不好
       // List<Student> list = dao.selectStudentByName("张%' or 1=1 or'");
        for (Student stu:list){
            System.out.println(stu);
        }
    }
    @Test
    public void test09(){
        Student student=new Student("张",23,-1);
        List<Student> list = dao.selectStudentByCondition(student);
        for (Student stu:list) {
            System.out.println(stu);
        }
    }
    @Test
    public  void test10(){
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("sname","李");
        map.put("sage",20);

        Student stu1 = new Student("李", 0, 0);
        Student stu2 = new Student(null, 20, 0);
        map.put("stu1",stu1);
        map.put("stu2",stu2);
        List<Student> list = dao.selectStudentByCondition2(map);
        for (Student stu:list){
            System.out.println(stu);
        }
    }
}
