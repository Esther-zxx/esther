package com.abc.dao;

import com.abc.bean.Student;

import java.util.List;
import java.util.Map;

public interface IStudentDao {
    public void insertStudent(Student student);
    public void insertStudentCatchId(Student student);
    public void updateStudent(Student student);
    public void deleteById(int id);
    public List<Student> selectAllStudent();
    public Student selectStudentById(int id);

    public Map<Object,Student> selectAllStudentMap();
    //模糊查询
    public List<Student> selectStudentByName(String name);
    //复合条件查询——对象封装
    public List<Student> selectStudentByCondition(Student student);
    //复合条件查询——Map封装
    public List<Student> selectStudentByCondition2(Map<String,Object> map);
}
