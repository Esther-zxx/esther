package com.abc.utils;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import java.io.IOException;
import java.io.InputStream;

public class MyBatisUtil {
    private static SqlSessionFactory factory;
    //工具类中异常处理通常是将异常抛出给方法调用者
    public static SqlSession getSqlSession() throws IOException {
        InputStream inputStream= Resources.getResourceAsStream("mybatis.xml");
       // SqlSessionFactory factory=null;
        if (factory==null){
            factory=new SqlSessionFactoryBuilder().build(inputStream);
        }
        return factory.openSession();

    }
}
