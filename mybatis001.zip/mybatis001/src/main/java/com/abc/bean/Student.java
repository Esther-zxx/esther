package com.abc.bean;

public class Student {
    private Integer id;
    private String name;
    private  int age;
    private double score;

    public Student() {
    }

    public Student(String name, int age, double score) {
        this.name = name;
        this.age = age;
        this.score = score;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }
    public String toString(){
        return "Student{"+
                "id="+id+
                ",name='"+name+'\''+
                ",age="+age+
                ",score="+score+
                        '}';
                }
    }

